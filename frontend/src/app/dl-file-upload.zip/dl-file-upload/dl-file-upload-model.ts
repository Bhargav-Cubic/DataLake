export class DlFileUploadModel{

    clientdetails:String;
    ispii:String;
    file_description:String;
    typeoffile:String;
    fileformat:String;
    isfileupload:String;
    mftfilefrequency:String;
    mftfileprefix:String;
    purgefrequency:String;
    filename:String; 
    filepath:string;
    tnc:String;
    uploaded_by:String;
}